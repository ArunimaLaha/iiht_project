export class Activity {

    public id : number;

    public userId : number;

    public activity : string;

    public date : string;

    public time : string;

    constructor(){}
}