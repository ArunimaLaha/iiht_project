export class Followers{
    public refId : number;
    public userId : number;
    public followerId : number;
    public followerName : string;
    public follower : string;
    public following : string;
    public followerPicture : string;
    constructor(){}
}