export class User {
    public userId : number;
    public username: string;
    public firstName: string;
    public lastName: string;
    public password:string;
    public email: string;
    public about: string;
    public profilePicture: string;
    public imageCount: number;
    public videoCount: number;
    public followerCount: number;
    public followingCount: number;
    constructor() { }
}