package com.social.imageApp.Pixogram.services;

import com.social.imageApp.Pixogram.model.Media;

public interface UploadService {

	Media saveSingleMedia(Media media);

}
