import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-multiple-media',
  templateUrl: './upload-multiple-media.component.html',
  styleUrls: ['./upload-multiple-media.component.css']
})
export class UploadMultipleMediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
