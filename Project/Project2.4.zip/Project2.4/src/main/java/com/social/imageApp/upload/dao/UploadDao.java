package com.social.imageApp.upload.dao;

import com.social.imageApp.model.Media;

public interface UploadDao {

	Media saveSingleMedia(Media media);

}
