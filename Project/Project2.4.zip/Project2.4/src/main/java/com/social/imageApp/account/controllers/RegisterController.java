package com.social.imageApp.account.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.social.imageApp.account.service.AccountService;
import com.social.imageApp.model.User;

@RestController
@Controller
public class RegisterController {

	private AccountService accountService;
	
	@Autowired(required = true)
	@Qualifier(value = "accountService")
	public void setCustomerService(AccountService accountService) {
		this.accountService = accountService;
	}
	
	@RequestMapping(value="/account/register", method = RequestMethod.POST)
	@CrossOrigin
	public ResponseEntity<User> registerUser(@RequestBody User user) {
		user = accountService.registerUser(user);
		System.out.println(user);
		return new ResponseEntity<User>(user,null, HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/account/check", method = RequestMethod.POST)
	@CrossOrigin
	public User checkUserName(@RequestBody String username) {
		User user = accountService.checkUserName(username);
		return user;
	}
}
