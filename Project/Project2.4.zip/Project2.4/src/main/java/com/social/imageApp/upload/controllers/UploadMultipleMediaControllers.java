package com.social.imageApp.upload.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class UploadMultipleMediaControllers {

}
