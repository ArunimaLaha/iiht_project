package com.social.imageApp.follow.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.social.imageApp.follow.service.FollowService;
import com.social.imageApp.model.Followers;
import com.social.imageApp.model.User;

@Controller
@RestController
public class FollowController {

	private FollowService followService;

	public FollowService getFollowService() {
		return followService;
	}

	@Autowired(required = true)
	@Qualifier(value = "followService")
	public void setFollowService(FollowService followService) {
		this.followService = followService;
	}

	@RequestMapping(value = "/follow/all", method = RequestMethod.POST)
	@CrossOrigin
	public List<Followers> fetchAll(@RequestBody User user) {
		return followService.fetchAll(user);
	}

	@RequestMapping(value = "/follow/follow", method = RequestMethod.POST)
	@CrossOrigin
	public Followers follow(@RequestBody Followers follower) {
		User user = followService.getUser(follower.getUserId());
		Followers follower1 = followService.getFollower(follower.getFollowerId(), user.getUserId());
		if (follower1 == null)
			follower = followService.createFollower(user, follower);
		else {
			follower = followService.follow(user, follower1);
		}
		return follower;
	}

	@RequestMapping(value = "/follow/unfollow", method = RequestMethod.POST)
	@CrossOrigin
	public Followers unfollow(@RequestBody Followers follower) {

		User user = followService.getUser(follower.getUserId());
		// Followers follower1 =
		// followService.getFollower(follower.getFollowerId(),user.getUserId());

		follower = followService.unfollow(user, follower);
		return follower;
	}

}
