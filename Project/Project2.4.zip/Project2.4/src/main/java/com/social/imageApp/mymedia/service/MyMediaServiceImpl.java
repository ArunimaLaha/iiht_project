package com.social.imageApp.mymedia.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.social.imageApp.model.Comment;
import com.social.imageApp.model.Like;
import com.social.imageApp.model.Media;
import com.social.imageApp.model.User;
import com.social.imageApp.mymedia.dao.MyMediaDao;

@Service
public class MyMediaServiceImpl implements MyMediaService {

	private MyMediaDao myMediaDao;
	
	@Autowired(required = true)
	@Qualifier(value="myMediaDao")
	public void setMyMediaDao(MyMediaDao myMediaDao) {
		this.myMediaDao = myMediaDao;
	}


	@Transactional
	public List<Media> getAllMedia(User user) {
		return myMediaDao.getAllMedia(user);
	}


	@Transactional
	public Media getMediaDetails(Media media) {
		return myMediaDao.getMediaDetails(media);
	}


	@Transactional
	public List<Comment> getComments(Media media) {
		return myMediaDao.getComments(media);
	}


	@Transactional
	public Comment saveComment(Comment comment) {
		return myMediaDao.saveComment(comment);
	}


	@Transactional
	public Like setLike(Like like) {
		return myMediaDao.setLike(like);
	}

}
