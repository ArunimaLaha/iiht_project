-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema pixogram
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema pixogram
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `pixogram` DEFAULT CHARACTER SET latin1 ;
USE `pixogram` ;

-- -----------------------------------------------------
-- Table `pixogram`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pixogram`.`user` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(12) NOT NULL,
  `firstname` VARCHAR(20) NOT NULL,
  `lastname` VARCHAR(20) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `password` VARCHAR(15) NOT NULL,
  `profilepicture` VARCHAR(255) NULL DEFAULT NULL,
  `about` VARCHAR(255) NULL DEFAULT NULL,
  `imagecount` INT(11) NULL DEFAULT NULL,
  `followercount` INT(11) NULL DEFAULT NULL,
  `followingcount` INT(11) NULL DEFAULT NULL,
  `videocount` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 8
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `pixogram`.`activity`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pixogram`.`activity` (
  `ref` INT(11) NOT NULL AUTO_INCREMENT,
  `userid` INT(11) NOT NULL,
  `activity` VARCHAR(255) NOT NULL,
  `date` VARCHAR(45) NULL DEFAULT NULL,
  `time` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`ref`),
  INDEX `userid_idx` (`userid` ASC),
  CONSTRAINT `userid`
    FOREIGN KEY (`userid`)
    REFERENCES `pixogram`.`user` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 14
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `pixogram`.`blocked`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pixogram`.`blocked` (
  `referenceid` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(12) NOT NULL,
  `blockeduser` VARCHAR(12) NOT NULL,
  `userid` INT(11) NULL DEFAULT NULL,
  `blockedid` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`referenceid`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `pixogram`.`comments`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pixogram`.`comments` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `userid` INT(11) NULL DEFAULT NULL,
  `mediaid` INT(11) NULL DEFAULT NULL,
  `commentorid` INT(11) NULL DEFAULT NULL,
  `commentorname` VARCHAR(12) NULL DEFAULT NULL,
  `comment` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 6
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `pixogram`.`followers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pixogram`.`followers` (
  `identitynumber` INT(11) NOT NULL AUTO_INCREMENT,
  `userid` INT(11) NULL DEFAULT NULL,
  `followerid` INT(11) NULL DEFAULT NULL,
  `follower` VARCHAR(1) NULL DEFAULT NULL,
  `following` VARCHAR(1) NULL DEFAULT NULL,
  `followerName` VARCHAR(12) NULL DEFAULT NULL,
  `followerPicture` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`identitynumber`))
ENGINE = InnoDB
AUTO_INCREMENT = 20
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `pixogram`.`likes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pixogram`.`likes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `userid` INT(11) NULL DEFAULT NULL,
  `mediaid` INT(11) NULL DEFAULT NULL,
  `likerid` INT(11) NULL DEFAULT NULL,
  `like` VARCHAR(1) NULL DEFAULT NULL,
  `likername` VARCHAR(12) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `pixogram`.`media`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pixogram`.`media` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(45) NULL DEFAULT NULL,
  `type` VARCHAR(5) NULL DEFAULT NULL,
  `poster` VARCHAR(45) NULL DEFAULT NULL,
  `description` VARCHAR(255) NULL DEFAULT NULL,
  `effect` VARCHAR(45) NULL DEFAULT NULL,
  `filename` VARCHAR(45) NULL DEFAULT NULL,
  `filetype` VARCHAR(45) NULL DEFAULT NULL,
  `filesize` VARCHAR(45) NULL DEFAULT NULL,
  `uploaddate` VARCHAR(45) NULL DEFAULT NULL,
  `uploadtime` VARCHAR(45) NULL DEFAULT NULL,
  `defaultprofile` INT(11) NULL DEFAULT NULL,
  `likes` INT(11) NULL DEFAULT NULL,
  `unlikes` INT(11) NULL DEFAULT NULL,
  `shares` INT(11) NULL DEFAULT NULL,
  `numberofcomments` INT(11) NULL DEFAULT NULL,
  `userid` INT(11) NULL DEFAULT NULL,
  `username` VARCHAR(12) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 6
DEFAULT CHARACTER SET = latin1;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
