package com.social.image.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.social.image.pojo.Image;

public class ImageDB {
	private static final String DB_DRIVER = "org.h2.Driver";
	private static final String DB_CONNECTION = "jdbc:h2:tcp://localhost/server~/test";
	private static final String DB_USER = "";
	private static final String DB_PASSWORD = "";

	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}

	public List<Image> getImages() throws SQLException {
		Connection connection = getDBConnection();
		String sql = "select * from images";
		List<Image> imageList = new ArrayList<Image>();
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			Image image = new Image();
			image.setImageId(resultSet.getInt("imageid"));
			image.setImageName(resultSet.getString("imagename"));
			image.setImageUrl(resultSet.getString("imageurl"));
			image.setTitle(resultSet.getString("title"));
			image.setDescription(resultSet.getString("description"));

			imageList.add(image);
		}
		preparedStatement.close();
		connection.close();
		return imageList;
	}

	public void storeImage(Image image) throws SQLException {
		Connection connection = getDBConnection();
		String sql = "insert into images (imagename,title,description,imageurl) values (?,?,?,?)";
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		preparedStatement.setString(1, image.getImageName());
		preparedStatement.setString(2, image.getTitle());
		preparedStatement.setString(3, image.getDescription());
		preparedStatement.setString(4, image.getImageUrl());
		preparedStatement.executeUpdate();
		preparedStatement.close();
		connection.close();
	}

}
