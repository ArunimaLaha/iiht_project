package com.social.image.service;

import java.sql.SQLException;
import java.util.List;

import com.social.image.database.ImageDB;
import com.social.image.pojo.Image;

public class ImageService {
	ImageDB imageDB = new ImageDB();

	public List<Image> getImages() throws SQLException {
		return imageDB.getImages();
	}

	public void storeImage(Image image) throws SQLException {
		imageDB.storeImage(image);
	}

}
