package com.social.image.controller;

import java.sql.SQLException;

import com.social.image.input.ImageInput;
import com.social.image.pojo.Image;
import com.social.image.service.ImageService;
import com.social.image.utilities.ImageValidation;

public class SingleImageInput {
	ImageInput imageInput = new ImageInput();
	ImageValidation imageValidation = new ImageValidation();
	ImageService imageService = new ImageService();

	public void addSingleImage() throws SQLException {
		Image image = imageInput.getImage();

		String message = imageValidation.validateImage(image);

		if (message.equals("success")) {
			imageService.storeImage(image);
			System.out.println("Image stored successfully");
		} else {
			System.out.println("Image Validation Error : " + message);
		}

	}
}
