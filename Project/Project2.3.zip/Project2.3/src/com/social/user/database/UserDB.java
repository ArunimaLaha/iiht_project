package com.social.user.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.social.user.pojo.User;

public class UserDB {
	private static final String DB_DRIVER = "org.h2.Driver";
	private static final String DB_CONNECTION = "jdbc:h2:~/test";
	private static final String DB_USER = "";
	private static final String DB_PASSWORD = "";

	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}

	public void registerUser(User user) throws SQLException {
		Connection connection = getDBConnection();
		String sql = "insert into user (firstname,lastname,username,email,password,image) values (?,?,?,?,?,?)";
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		preparedStatement.setString(1, user.getFirstName());
		preparedStatement.setString(2, user.getLastName());
		preparedStatement.setString(3, user.getUserName());
		preparedStatement.setString(4, user.getEmail());
		preparedStatement.setString(5, user.getPassword());
		preparedStatement.setString(6, user.getProfilePicture());
		preparedStatement.executeUpdate();
		preparedStatement.close();
		connection.close();
	}

	public List<User> getUserListByChoice(int choice) throws SQLException {
		Connection connection = getDBConnection();
		String sql = "";
		List<User> userList = new ArrayList<User>();
		if (choice == 1) {
			sql = "select userid,firstname,lastname,username,email,image from user order by firstname";
		} else {
			sql = "select userid,firstname,lastname,username,email,image from user order by lastname";
		}
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			User user = new User();
			user.setUserId(resultSet.getInt("userid"));
			user.setFirstName(resultSet.getString("firstname"));
			user.setLastName(resultSet.getString("lastname"));
			user.setUserName(resultSet.getString("username"));
			user.setEmail(resultSet.getString("email"));
			user.setProfilePicture(resultSet.getString("image"));

			userList.add(user);
		}
		preparedStatement.close();
		connection.close();
		return userList;
	}

	public User checkUser(User user) throws SQLException {
		Connection connection = getDBConnection();
		String sql = "select userid,firstname,lastname,username,email,image from user where username=? and password=?";
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		preparedStatement.setString(1, user.getUserName());
		preparedStatement.setString(2, user.getPassword());
		ResultSet resultSet = preparedStatement.executeQuery();
		if (!resultSet.isBeforeFirst()) {
			return null;

		} else {
			while (resultSet.next()) {
				user.setUserId(resultSet.getInt("userid"));
				user.setFirstName(resultSet.getString("firstname"));
				user.setLastName(resultSet.getString("lastname"));
				user.setUserName(resultSet.getString("username"));
				user.setEmail(resultSet.getString("email"));
				user.setProfilePicture(resultSet.getString("image"));
			}
			return user;
		}

	}

	public int updateUser(User user) throws SQLException {

		Connection connection = getDBConnection();
		String sql = "update user set firstname=?, lastname=?,username=?,email=?,password=?,image=? where userid=?";
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		preparedStatement.setString(1, user.getFirstName());
		preparedStatement.setString(2, user.getLastName());
		preparedStatement.setString(3, user.getUserName());
		preparedStatement.setString(4, user.getEmail());
		preparedStatement.setString(5, user.getPassword());
		preparedStatement.setString(6, user.getProfilePicture());
		preparedStatement.setInt(7, user.getUserId());
		int status = preparedStatement.executeUpdate();
		return status;
	}
}
