package com.social.user.utilities;

import com.social.user.pojo.User;

public class UserValidation {
	public String validateUser(User user) {
		String message = "";
		boolean valid = true;
		if (user.getFirstName() == null || (!user.getFirstName().matches("^[a-zA-Z]*$"))) {
			message = message + "\n" + "First Name should contain only alphabets";
			valid = false;

		}
		if (user.getLastName() == null || (!user.getLastName().matches("^[a-zA-Z]*$"))) {
			message = message + "\n" + "Last Name should contain only alphabets";
			valid = false;
		}
		if (user.getUserName() == null || (!user.getUserName().matches("[a-zA-Z0-9]*"))) {
			message = message + "\n" + "User Name should contain only alphanumeric characters";
			valid = false;
		}
		if (Character.isDigit(user.getUserName().charAt(0))) {
			message = message + "\n" + "User Name cannot start with a number";
			valid = false;
		}
		if (user.getUserName().length() < 8 || user.getUserName().length() > 12) {
			message = message + "\n" + "User Name should be inbetween 8 and 12 characters";
			valid = false;
		}

		String regex = "^[A-Za-z0-9+_.-]+@(.+)$";

		if (user.getEmail() == null || (!user.getEmail().matches(regex))) {
			message = message + "\n" + "Check the email id entered";
			valid = false;
		}

		if (user.getPassword() == null || (!user.getPassword().matches("[a-zA-Z0-9#%$!]*"))) {
			message = message + "\n" + "Password should be alphanumeric with #,$,%,! special characters";
			valid = false;
		}

		if (user.getPassword().length() < 8 || user.getPassword().length() > 12) {
			message = message + "\n" + "Password should be inbetween 8 and 12 characters";
			valid = false;
		}

		boolean hasUppercase = !user.getPassword().equals(user.getPassword().toLowerCase());
		if (!hasUppercase) {
			message = message + "\n" + "Password must have atleast one capital alphabet";
			valid = false;
		}
		if (valid == true)
			return "success";
		else
			return message;
	}
}
