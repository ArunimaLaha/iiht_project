package com.social.user.input;

import java.sql.SQLException;
import java.util.Scanner;

import com.social.user.database.UserDB;
import com.social.user.pojo.User;
import com.social.user.utilities.UserValidation;

public class UserInput {
	Scanner s = new Scanner(System.in);
	UserValidation userValidation = new UserValidation();
	UserDB userDB = new UserDB();

	public User getUserRegistrationInput() throws SQLException {
		User user = new User();
		System.out.println("Enter First Name");
		user.setFirstName(s.nextLine());
		System.out.println("Enter Last Name");
		user.setLastName(s.nextLine());
		System.out.println("Enter User Name");
		user.setUserName(s.nextLine());
		System.out.println("Enter Email");
		user.setEmail(s.nextLine());
		System.out.println("Enter Password");

		// to be modified
		user.setPassword(s.nextLine());

		System.out.println("Profile Picture");
		user.setProfilePicture(s.nextLine());

		return user;
		/*
		 * String message = userValidation.validateUser(user);
		 * 
		 * if (message.equals("success")) { userDB.registerUser(user); } else {
		 * System.out.println("Validation Error : " + message); }
		 */

	}

	public int getChoice() {
		int choice = s.nextInt();
		s.nextLine();
		return choice;
	}

	public User loginInput() {
		User user = new User();
		System.out.println("Enter username");
		user.setUserName(s.nextLine());
		System.out.println("Enter password");
		user.setPassword(s.nextLine());

		return user;
	}

	public String getString() {
		return s.nextLine();
	}

}
